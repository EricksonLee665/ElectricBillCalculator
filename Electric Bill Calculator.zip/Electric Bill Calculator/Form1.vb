﻿Public Class Form1
    Public Property CalculateMonthlyBill As Integer

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub MeterReading1(sender As Object, e As EventArgs) Handles Label1.Click
        Console.WriteLine("MeterReading1")
        Console.ReadLine()


    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CalculateEnergyUsed_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim CalculateEnergyUsed As Integer
        Dim MeterReading1 As Integer
        Dim MeterReading2 As Integer


        CalculateEnergyUsed = Val(TextBox2.Text) - Val(TextBox1.Text)
        TextBox7.Text = CalculateEnergyUsed


    End Sub

    Private Sub MeterReading2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Console.WriteLine("MeterReading2")

        Console.ReadLine()
    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged



    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        Console.WriteLine("CostPerKWh")
        Console.ReadLine()


    End Sub

    Private Sub CalculateEnergyCost_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim CalculateEnergyCost As Integer
        Dim CostInKWh As Integer
        Dim EnergyCost As Integer

        CalculateEnergyCost = Val(TextBox7.Text) * Val(TextBox3.Text)
        TextBox8.Text = CalculateEnergyCost


    End Sub

    Private Sub CalculateMonthlyBill_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim CalculateMonthlyBill As Integer
        Dim MonthlyTax As Integer
        Dim MonthlyBill As Integer


        CalculateMonthlyBill = Val(TextBox8.Text) + Val(TextBox5.Text)
        TextBox6.Text = CalculateMonthlyBill

    End Sub

End Class
